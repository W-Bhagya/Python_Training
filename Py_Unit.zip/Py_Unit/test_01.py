import unittest


class TestExample(unittest.TestCase):
    def test_upper(self):
        self.assertEqual('bhagya'.upper(), 'BHAGYA')

    def test_isupper(self):
        self.assertTrue('BHAGYA'.isupper())
        self.assertTrue('BHAGYA'.islower())


if __name__ == "__main__":
    unittest.main()