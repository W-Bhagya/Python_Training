import re
text = "1127/2021"

if re.match(r'\d + /\d + /\d +',text) :
    print("Yes")
else :
    print("No")
