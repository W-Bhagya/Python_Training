from jinja2 import Environment ,FileSystemLoader
persons = [
    {"name" : "Neha","Age":20},
    {"name" : "Vinnie", "Age": 16},
    {"name" : "Bhagya", "Age": 22},
    {"name" : "Abhi", "Age": 23}
]

file_loader = FileSystemLoader('Templates')
env = Environment(loader=file_loader)
Templates = env.get_template('show.txt')

output = Templates.render(persons=persons)
print(output)