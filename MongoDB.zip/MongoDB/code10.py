<metadata>
<food>
    <item name="breakfast">Idly</item>
    <price newprices="yes">12.5</price>
    <description>
   Two idly's with chutney
   </description>
    <calories>553</calories>
<tasty>YES</tasty></food>
<food>
    <item name="breakfast">Upma</item>
    <price newprices="yes">13.65</price>
    <description>
    Rava upma with bajji
    </description>
    <calories>600</calories>
</food>
<food>
    <item name="breakfast">Bisi Bele Bath</item>
    <price newprices="yes">14.5</price>
    <description>
   Bisi Bele Bath with sev
    </description>
    <calories>400</calories>
</food>
<food>
    <item name="breakfast">Kesari Bath</item>
    <price newprices="yes">11.95</price>
    <description>
    Sweet rava with saffron
    </description>
    <calories>950</calories>
</food>
</metadata>